<?php

namespace App\Http\Controllers;

use App\Models\Counter;
use App\Models\Shift;
use Illuminate\Http\Request;
use PHPUnit\Framework\Constraint\Count;

class ShiftController extends Controller
{
    public function openShift(Request $request)
    {
        // Check if user already has an open shift
        $existingShift = Shift::where('user_id', $request->user()->id)
            ->where('status', 'open')
            ->first();

        if ($existingShift) {
            return response()->json(['message' => 'You already have an open shift.'], 400);
        }

        $shift = Shift::create([
            'user_id'      => $request->user()->id,
            'counter_id'   => $request->counter_id,
            'name'         => $request->user()->name ?? 'Shift ' . now()->format('d-m-Y H:i'),
            'start_time'   => now(),
            'opening_cash' => $request->opening_cash ?? 0,
            'status'       => 'open',
        ]);

        return response()->json($shift, 201);
    }

    // Close a shift
    public function closeShift(Request $request)
    {
        $shift = Shift::where('id', $request->user()->id)
            ->where('user_id', $request->user()->id)
            ->where('status', 'open')
            ->first();

        if (! $shift) {
            return response()->json(['message' => 'No open shift found.'], 404);
        }

        $shift->update([
            'end_time'       => now(),
            'closing_cash'   => $request->closing_cash ?? 0,
            'total_sales'    => $request->total_sales ?? 0,
            'total_expenses' => $request->total_expenses ?? 0,
            'status'         => 'closed',
        ]);

        return response()->json($shift);
    }

    // Get current open shift
    public function currentShift($id)
    {
        $shift = Shift::where('user_id', $id)
            ->where('status', 'open')
            ->first();

        return response()->json($shift ?? ['message' => 'No open shift']);
    }

    // List all shifts for user
    public function allShiftsById($id)
    {
        $shifts = Shift::where('user_id', $id)
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json($shifts);
    }

    public function allShifts($id)
    {
        $shifts = Shift::where('user_id', '!=', $id)
            ->orderBy('created_at', 'desc')
            ->get();
        return response()->json($shifts);
    }

    public function allCounters()
    {
        $shifts = Counter::orderBy('created_at', 'desc')
            ->get();
        return response()->json($shifts);
    }
}
